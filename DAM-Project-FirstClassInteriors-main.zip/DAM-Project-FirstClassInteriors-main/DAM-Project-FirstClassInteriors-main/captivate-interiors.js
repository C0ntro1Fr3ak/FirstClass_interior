
/*function CEOtoMD{
    document.getElementById("CEOheading").innerHTML = "New text!";
}*/



/* function CEOtoMD()
{
    var CEOheading=document.getElementById("CEOheading").innerHTML;
    var CEOdescription=document.getElementById("CEOdescription");
    var CEOimg=document.getElementById("CEOimg");
    var CEOBtn=document.getElementById("CEOBtn");
    var submitbutton=document.getElementsByClassName("submit-button");

    if(CEOheading.textContent =="Kermit de Frog, Chief Executive Officer")
    {
        CEOheading.innerHTML="Red Fraggle, Managing Director";
        CEOheading.style=bold;
        CEOheading.style.color="#45003e";
        CEOdescription.innerHTML="We don’t serve their kind here! What? Your droids. They’ll have to wait outside. We don’t want them here. Listen, why don’t you wait out by the speeder. We don’t want any trouble. I heartily agree with you sir. Negola dewaghi wooldugger?!? He doesn’t like you. I’m sorry. I don’t like you either You just watch yourself. We’re wanted men. I have the death sentence in twelve systems. I’ll be careful than. You’ll be dead. This little one isn’t worth the effort. Come let me buy you something…";
        CEOimg.src="images/red-350px-350px.jpg";
        CEOBtn.innerHTML="Change to CEO";
    }

    else{
        CEOheading.innerHTML="Kermit de Frog, Chief Executive Officer";
        CEOheading.style=bold;
        CEOdescription.innerHTML="I had to face my fear…that was more important than just going on living…. I don’t like it. Geronimo! There’s always something to look at if you open your eyes! And everybody lives, Rose! Everybody lives! I need more days like this! Go on, ask me anything; I’m on fire! Goodbye, Clara. Alright? Of course I’m alright, my child. You know, I am so constantly outwitting the opposition, I tend to forget the delights and satisfaction of the gentle art of fisticuffs. Well, I’m still not the man I used to be… thank goodness.";
        CEOimg.src="images/originals/kermit-portrait.jpg";
        CEOBtn.innerHTML="See managing Director Details";
        }


} */


