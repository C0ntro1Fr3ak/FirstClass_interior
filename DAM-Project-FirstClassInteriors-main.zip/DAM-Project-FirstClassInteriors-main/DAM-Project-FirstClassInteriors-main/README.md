# DAM-Project-FirstClassInteriors
Data Assett Management - For Captivate Interiors by Mind Motionists

Team: 
Project Lead: Annette Bigby
Gather Regquirements: Team contributed questions relevant to their roles
Code: Kishan MaiSuria
Designer: Robert Thomson
Tester: Philli Park-Tamati





